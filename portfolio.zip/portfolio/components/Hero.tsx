"use client";

import { motion } from "framer-motion";
import { useMouse } from "@/hooks/useMouse";
import { fadeUp } from "@/animations/fadeUp";
import { staggerContainer, staggerItem } from "@/animations/stagger";
import Button from "@/components/ui/Button";
import GradientText from "@/components/ui/GradientText";
import SectionLabel from "@/components/ui/SectionLabel";
import HeroPortrait from "@/components/HeroPortrait";
import GlowOrb from "@/components/ui/GlowOrb";
import { resumeUrl } from "@/data/links";
import { ArrowDown, ArrowRight } from "lucide-react";

const roles = ["Software Engineer", "ML Builder", "Full-Stack Developer"];

export default function Hero() {
  const { x, y } = useMouse();

  return (
    <section className="relative flex min-h-screen flex-col justify-center overflow-hidden px-6 pt-28">
      {/* mouse spotlight */}
      <div
        className="pointer-events-none absolute inset-0 z-0 opacity-70 transition-opacity"
        style={{
          background: `radial-gradient(500px circle at ${x}px ${y}px, rgba(233,53,224,0.10), transparent 70%)`,
        }}
      />
      {/* subtle grid */}
      <div
        className="pointer-events-none absolute inset-0 z-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)",
          backgroundSize: "56px 56px",
        }}
      />
      <GlowOrb className="left-[-120px] top-[10%]" size={360} />
      <GlowOrb className="right-[-100px] bottom-[5%]" size={420} />

      <div className="relative z-10 mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-12 lg:grid-cols-[1.2fr_0.8fr]">
        <motion.div
          variants={staggerContainer(0.12)}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={staggerItem}>
            <SectionLabel>Portfolio — 2026</SectionLabel>
          </motion.div>

          <motion.h1
            variants={staggerItem}
            className="mt-6 font-display text-5xl leading-[1.05] sm:text-6xl lg:text-7xl"
          >
            Nayana J{" "}
            <GradientText as="span" className="italic">
              Pillai
            </GradientText>
          </motion.h1>

          <motion.div
            variants={staggerItem}
            className="mt-4 flex flex-wrap items-center gap-2 text-lg text-text-muted sm:text-xl"
          >
            <span>Aspiring</span>
            <span className="gradient-text font-medium">
              {roles.join(" · ")}
            </span>
          </motion.div>

          <motion.p
            variants={staggerItem}
            className="mt-6 max-w-xl text-base leading-relaxed text-text-muted"
          >
            B.Tech Computer Science undergraduate building full-stack and
            machine learning systems — from a 95%-accurate fertilizer
            recommendation engine to real-time health alerting. I care about
            software that ships, and communities that grow.
          </motion.p>

          <motion.div
            variants={staggerItem}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <Button href={resumeUrl} download icon={<ArrowDown size={16} />}>
              Download Resume
            </Button>
            <Button href="/projects" variant="ghost" icon={<ArrowRight size={16} />}>
              View Projects
            </Button>
          </motion.div>
        </motion.div>

        <motion.div variants={fadeUp} initial="hidden" animate="visible">
          <HeroPortrait />
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 z-10 flex -translate-x-1/2 flex-col items-center gap-2 text-text-faint"
      >
        <span className="text-[10px] uppercase tracking-[0.3em]">
          Scroll to explore
        </span>
        <motion.span
          animate={{ y: [0, 6, 0] }}
          transition={{ repeat: Infinity, duration: 1.8 }}
        >
          <ArrowDown size={14} />
        </motion.span>
      </motion.div>
    </section>
  );
}
