"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { runPixelReveal } from "@/animations/pixelReveal";

const SIZE = 380;

export default function HeroPortrait() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [revealed, setRevealed] = useState(false);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = SIZE;
    canvas.height = SIZE;

    const img = new window.Image();
    img.src = "/images/profile.jpg";
    img.crossOrigin = "anonymous";
    img.onload = () => {
      runPixelReveal(canvas, img, () => setRevealed(true));
    };
  }, []);

  function handleMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    const rect = wrapperRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 16;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -16;
    setTilt({ x, y });
  }

  function handleMouseLeave() {
    setTilt({ x: 0, y: 0 });
  }

  return (
    <motion.div
      ref={wrapperRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
      className="relative mx-auto flex items-center justify-center"
      style={{ width: SIZE, height: SIZE }}
    >
      {/* glow ring */}
      <div
        className="absolute inset-[-24px] rounded-[2rem] bg-accent-gradient opacity-60 blur-2xl transition-opacity duration-500"
        style={{ opacity: revealed ? 0.55 : 0.25 }}
        aria-hidden="true"
      />

      <div
        className="relative overflow-hidden rounded-[1.75rem] border border-border-strong shadow-glow transition-transform duration-200 ease-out"
        style={{
          transform: `perspective(800px) rotateX(${tilt.y}deg) rotateY(${tilt.x}deg)`,
        }}
      >
        <canvas
          ref={canvasRef}
          width={SIZE}
          height={SIZE}
          className="block [filter:contrast(1.05)_saturate(0.9)] [mix-blend-mode:normal]"
          style={{
            background:
              "linear-gradient(135deg, rgba(255,77,141,0.25), rgba(139,59,240,0.25))",
          }}
        />
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "linear-gradient(160deg, rgba(255,77,141,0.18) 0%, transparent 40%, rgba(139,59,240,0.22) 100%)",
            mixBlendMode: "color",
          }}
        />
      </div>

      {/* corner label, echoing the VISION poster's typographic tags */}
      <span className="absolute -bottom-6 left-0 text-[10px] uppercase tracking-[0.3em] text-text-faint">
        CS · Chengannur
      </span>
      <span className="absolute -top-6 right-0 text-[10px] uppercase tracking-[0.3em] text-text-faint">
        Est. 2023
      </span>
    </motion.div>
  );
}
