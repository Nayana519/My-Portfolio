"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { navLinks, resumeUrl } from "@/data/links";
import Button from "@/components/ui/Button";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="fixed top-4 left-1/2 z-50 w-[94%] max-w-4xl -translate-x-1/2"
    >
      <nav
        className={cn(
          "flex items-center justify-between rounded-full px-5 py-2.5 transition-all duration-300 glass",
          scrolled && "shadow-glow-sm border-border-strong"
        )}
      >
        <Link
          href="/"
          className="font-display text-lg italic tracking-tight text-text-primary"
        >
          nayana<span className="gradient-text">.</span>
        </Link>

        <ul className="hidden items-center gap-6 md:flex">
          {navLinks.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                className="text-sm text-text-muted transition-colors hover:text-text-primary"
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        <Button href={resumeUrl} download variant="primary" className="!px-4 !py-2 text-xs">
          Resume
        </Button>
      </nav>
    </motion.header>
  );
}
