"use client";

import { motion } from "framer-motion";
import Card from "@/components/ui/Card";
import { staggerContainer, staggerItem } from "@/animations/stagger";
import { SkillCategory } from "@/types";

export default function SkillCategoryCard({
  category,
  index,
}: {
  category: SkillCategory;
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
    >
      <Card className="h-full">
        <h3 className="font-display text-lg text-text-primary">
          {category.title}
        </h3>
        <motion.div
          variants={staggerContainer(0.04)}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mt-4 flex flex-wrap gap-2"
        >
          {category.skills.map((skill) => (
            <motion.span
              key={skill}
              variants={staggerItem}
              className="rounded-full border border-border px-3 py-1.5 text-xs text-text-muted transition-colors hover:border-accent-2 hover:text-text-primary"
            >
              {skill}
            </motion.span>
          ))}
        </motion.div>
      </Card>
    </motion.div>
  );
}
