"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useInView } from "@/hooks/useInView";
import { Stat } from "@/types";
import { formatNumber } from "@/lib/utils";

export default function StatCounter({ stat }: { stat: Stat }) {
  const { ref, inView } = useInView<HTMLDivElement>(0.4);
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const duration = 1400;
    const start = performance.now();

    function tick(now: number) {
      const t = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(stat.value * eased);
      if (t < 1) requestAnimationFrame(tick);
      else setDisplay(stat.value);
    }
    requestAnimationFrame(tick);
  }, [inView, stat.value]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5 }}
      className="glass rounded-2xl px-6 py-8 text-center"
    >
      <p className="font-display text-3xl gradient-text sm:text-4xl">
        {stat.prefix}
        {formatNumber(display)}
        {stat.suffix}
      </p>
      <p className="mt-2 text-xs uppercase tracking-[0.2em] text-text-muted">
        {stat.label}
      </p>
    </motion.div>
  );
}
