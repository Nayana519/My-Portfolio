import { heroStats } from "@/data/stats";
import StatCounter from "@/components/StatCounter";

export default function StatsBand() {
  return (
    <section className="relative z-10 px-6 py-16">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-4 sm:grid-cols-4">
        {heroStats.map((stat) => (
          <StatCounter key={stat.id} stat={stat} />
        ))}
      </div>
    </section>
  );
}
