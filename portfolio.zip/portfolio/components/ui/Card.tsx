"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface CardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}

export default function Card({ children, className, hover = true }: CardProps) {
  return (
    <motion.div
      whileHover={
        hover
          ? { y: -6, borderColor: "var(--border-strong)" }
          : undefined
      }
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={cn(
        "glass rounded-2xl p-6",
        hover && "hover:shadow-glow-sm",
        className
      )}
    >
      {children}
    </motion.div>
  );
}
