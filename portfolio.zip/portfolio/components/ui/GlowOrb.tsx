import { cn } from "@/lib/utils";

interface GlowOrbProps {
  className?: string;
  size?: number;
}

export default function GlowOrb({ className, size = 400 }: GlowOrbProps) {
  return (
    <div
      className={cn(
        "pointer-events-none absolute rounded-full bg-radial-glow blur-3xl animate-float",
        className
      )}
      style={{ width: size, height: size }}
      aria-hidden="true"
    />
  );
}
