import { cn } from "@/lib/utils";

interface SectionLabelProps {
  children: React.ReactNode;
  className?: string;
}

export default function SectionLabel({ children, className }: SectionLabelProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-3 text-xs uppercase tracking-[0.35em] text-text-muted",
        className
      )}
    >
      <span className="h-px w-8 bg-accent-gradient" />
      {children}
    </span>
  );
}
